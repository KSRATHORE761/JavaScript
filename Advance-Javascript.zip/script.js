//                 CH - Advance Topics

// For loop: When you know how many times you have to loop.
// While : When you don't know how many times you have to loop.

finished = true;
while (finished == true) {
  console.log('looping');
}